<?php
 
namespace TerrificMinds\DocumentValidation\Model\Config;
 
class MultiselectFileExtention implements \Magento\Framework\Option\ArrayInterface
{
 
    public function toOptionArray()
    {
        return [
            ['value' => 0, 'label' => __('Pdf')],
            ['value' => 1, 'label' => __('png')],
            ['value' => 2, 'label' => __('jpg')]
        ];
    }
}