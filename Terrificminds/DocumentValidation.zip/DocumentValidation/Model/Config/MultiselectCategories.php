<?php

namespace TerrificMinds\DocumentValidation\Model\Config;

class MultiselectCategories implements \Magento\Framework\Option\ArrayInterface
{
    protected $_storeManager;
    protected $_categoryCollection;

    /**
     * @param \Magento\Backend\Block\Template\Context $context

     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory $categoryCollection,
        array $data = []
    ) {
        $this->_storeManager = $storeManager;
        $this->_categoryCollection = $categoryCollection;
        // $this->context = $context;
        $this->context = $context;
    }

  
    public function toOptionArray()
    {
        $cat=[];
        $categories = $this->_categoryCollection->create()->addAttributeToSelect('*')
        ->setStore($this->_storeManager->getStore()); //categories from current store will be fetched
        $i=0;
            foreach ($categories as $category){
                $cat[$i]=$category->getName();
                $i++;
            }
            $res = [];
            for($j=0;$j<$i;$j++) {
                $res[] = ['value' => $j, 'label' => $cat[$j]];
            }
            return $res;
            
        }
}