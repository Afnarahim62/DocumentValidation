var config = {
    config: {
        mixins: {
            'Magento_Checkout/js/action/place-order': {
                'Terrificminds_DocumentValidation/js/order/place-order-mixin': true
            },
        }
    }
};