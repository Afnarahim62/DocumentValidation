<?php

namespace Terrificminds\CustomField\Controller\Quote;

use Magento\Catalog\Model\Category;

class filesave extends \Magento\Framework\App\Action\Action
{

    protected $category;
   /**
    * @var \Magento\Checkout\Model\Session
    */
    protected $checkoutSession;

    /**
     * Undocumented function
     *
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Quote\Api\CartRepositoryInterface $quoteRepository
     * @param \Magento\Checkout\Model\Session $checkoutSession
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Catalog\Model\Category $category
    ) {
        parent::__construct($context);
        $this->checkoutSession = $checkoutSession;
        $this->category = $category;
    }

    /**
     * @return \Magento\Framework\Controller\Result\Raw
     */
    public function execute()
    { 
        $post = $this->getRequest()->getPostValue();
        $quote = $this->checkoutSession->getQuote();
        /** @var \Magento\Quote\Model\Quote\Item $item */
        foreach($quote->getAllVisibleItems() as $item){
             $categoryIds = $item->getProduct()->getCategoryIds();
        }
       
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/custom.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);
       $logger->info("/////////////////-----logger initiated-----//////////////////////");
        $logger->info("save " . print_r($cat, true));
    }
}