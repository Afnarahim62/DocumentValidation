define([
    'ko',
    'uiComponent',
    'jquery',
    'underscore',
    'mage/url',
    'Magento_Ui/js/modal/modal',
    'Magento_Checkout/js/model/url-builder',
], function (ko, Component,$, _,urlFormatter, modal,urlBuilder, ) {
    'use strict';
    // ko.applyBindings(new ViewModel());
    return Component.extend({
        defaults: {
            template: 'Terrificminds_CustomField/shipping/landmark'
        },
       initialize: function () {
        this._super();
        this.hello();
        this.showCheckbox = ko.observable(true);
        var url = urlFormatter.build('terrificminds/quote/filesave');
        var option = "data";
        var result = true;
        $.ajax({
            url: url,
            // data: option,
            // dataType: 'text',
            type: 'POST',
        }).done(
            function (response) {
                result = true;
            }
        ).fail(
            // function (response) {
            //     if (response.success) {

            //     }
            // }
            function (response) {
                result = false;
            }
        );
      },
      hello: function(){
        console.log("helooo");
        return;
      },
    
    });
    

});