var config = {
    config: {
        mixins: {
            'Magento_Checkout/js/action/place-order': {
                'Terrificminds_CustomField/js/order/place-order-mixin': true
            },
        }
    }
};