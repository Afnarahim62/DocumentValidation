<?php
namespace Terrificminds\CustomField\Plugin\Checkout;

class LayoutProcessor
{
    /**
     * @param \Magento\Checkout\Block\Checkout\LayoutProcessor $subject
     * @param array $jsLayout
     * @return array
     */
    public function afterProcess(
        \Magento\Checkout\Block\Checkout\LayoutProcessor $subject,
        array  $jsLayout
    ) {
      
        
        //  $jsLayout['components']['checkout']['children']['steps']['children']['shipping-step']['children']
        //  ['shippingAddress']['children']['before-form']['children']['tm_landmark'] = [
        //  'component' => 'Magento_Ui/js/form/element/text',
        //      'config' => [
        //          'customScope' => 'shippingAddress',
        //          'template' => 'ui/form/field',
        //          'elementTmpl' => 'ui/form/element/text',
        //          'options' => [],
        //          'id' => 'tm_landmark'
        //      ],
        //      'dataScope' => 'shippingAddress.tm_landmark',
        //      'label' => __('Landmark'),
        //      'provider' => 'checkoutProvider',
        //      'visible' => true,
        //      'validation' => [],
        //      'sortOrder' => 1,
        //      'id' => 'tm_landmark'
        //  ];
        //  $jsLayout['components']['checkout']['children']['steps']['children']['shipping-step']['children']
        //  ['shippingAddress']['children']['before-form']['children']['my_custom_file'] = [
        //  'component' => 'Magento_Ui/js/form/element/file-uploader',
        //      'config' => [
        //          'customScope' => 'shippingAddress',
        //          'template' => 'ui/form/field',
        //          'elementTmpl' => 'ui/form/element/input',
        //          'options' => [],
        //          'id' => 'my_custom_file'
        //      ],
        //      'dataScope' => 'shippingAddress.my_custom_file',
        //      'label' => __('my_custom_file'),
        //      'provider' => 'checkoutProvider',
        //      'visible' => true,
        //      'validation' => [],
        //      'sortOrder' => 1,
        //      'id' => 'my_custom_file'
        //  ];
        //    $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/custom.log');
        // $logger = new \Zend_Log();
        // $logger->addWriter($writer);
        // $logger->info("/////////////////-----logger initiated-----//////////////////////");
        // $logger->info("js layout " . print_r($jsLayout['components']['checkout']['children']['steps']['children']['shipping-step']['children']
        // ['shippingAddress']['children'], true));

        return $jsLayout;
    }
}